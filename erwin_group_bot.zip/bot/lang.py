import json
import os

def get_lang(chat_id):
    if os.path.exists("group_lang.json"):
        with open("group_lang.json", "r") as file:
            data = json.load(file)
        return data.get(str(chat_id), "en")
    return "en"

def set_lang(chat_id, lang_code):
    if os.path.exists("group_lang.json"):
        with open("group_lang.json", "r") as file:
            data = json.load(file)
    else:
        data = {}
    data[str(chat_id)] = lang_code
    with open("group_lang.json", "w") as file:
        json.dump(data, file)

def get_string(lang, key):
    try:
        with open(f"languages/{lang}.json", "r") as file:
            strings = json.load(file)
        return strings.get(key, key)
    except:
        return key
