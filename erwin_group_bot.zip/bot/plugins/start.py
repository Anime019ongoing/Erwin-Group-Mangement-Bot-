from pyrogram import Client, filters
from pyrogram.types import InlineKeyboardMarkup, InlineKeyboardButton
from bot.lang import get_lang, get_string

@Client.on_message(filters.command("start"))
async def start(client, message):
    lang = get_lang(message.chat.id)
    text = get_string(lang, "start_text")
    buttons = InlineKeyboardMarkup([
        [InlineKeyboardButton("ᴀᴅᴅ ᴛᴏ ɢʀᴏᴜᴘ", url=f"https://t.me/{client.me.username}?startgroup=true")],
        [InlineKeyboardButton("ʀᴜʟᴇs", callback_data="rules"), InlineKeyboardButton("sᴇᴛ ʟᴀɴɢᴜᴀɢᴇ", callback_data="setlang")],
        [InlineKeyboardButton("sᴜᴘᴘᴏʀᴛ", url="https://t.me/your_support"), InlineKeyboardButton("ᴄʜᴀɴɴᴇʟ", url="https://t.me/your_channel")]
    ])
    photo = ""  # <--- paste your image URL here
    await message.reply_photo(photo=photo, caption=text, reply_markup=buttons)
